package com.cpsc471.group69.DeckDuels.game;
public class BannedPlayerException extends Exception{
    BannedPlayerException(String msg) {
        super(msg);
    }
}
