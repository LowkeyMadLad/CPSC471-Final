package com.cpsc471.group69.DeckDuels;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeckDuelsApplicationTests {

	@Test
	void contextLoads() {
	}

}
